import { useState } from 'react';
import PayviaLanding from './PayviaLanding';
import PayviaAPITester from './components/PayviaAPITester';
import ComplianceApp from './ComplianceApp';
import MerchantAnalyticsApp from './MerchantAnalyticsApp';
import DocsPortal from './DocsPortal';

function App() {
  const [currentView, setCurrentView] = useState<'landing' | 'tester' | 'compliance' | 'analytics' | 'docs'>('landing');

  return (
    <div>
      <div className="fixed top-4 right-4 z-50 flex gap-2">
        <button
          onClick={() => setCurrentView('landing')}
          className={`px-4 py-2 rounded-lg font-medium transition-all shadow-lg ${
            currentView === 'landing'
              ? 'bg-blue-600 text-white'
              : 'bg-white text-slate-700 hover:bg-slate-50'
          }`}
        >
          Landing Page
        </button>
        <button
          onClick={() => setCurrentView('tester')}
          className={`px-4 py-2 rounded-lg font-medium transition-all shadow-lg ${
            currentView === 'tester'
              ? 'bg-blue-600 text-white'
              : 'bg-white text-slate-700 hover:bg-slate-50'
          }`}
        >
          API Tester
        </button>
        <button
          onClick={() => setCurrentView('compliance')}
          className={`px-4 py-2 rounded-lg font-medium transition-all shadow-lg ${
            currentView === 'compliance'
              ? 'bg-blue-600 text-white'
              : 'bg-white text-slate-700 hover:bg-slate-50'
          }`}
        >
          Compliance
        </button>
        <button
          onClick={() => setCurrentView('analytics')}
          className={`px-4 py-2 rounded-lg font-medium transition-all shadow-lg ${
            currentView === 'analytics'
              ? 'bg-blue-600 text-white'
              : 'bg-white text-slate-700 hover:bg-slate-50'
          }`}
        >
          Merchant Analytics
        </button>
        <button
          onClick={() => setCurrentView('docs')}
          className={`px-4 py-2 rounded-lg font-medium transition-all shadow-lg ${
            currentView === 'docs'
              ? 'bg-blue-600 text-white'
              : 'bg-white text-slate-700 hover:bg-slate-50'
          }`}
        >
          Documentation
        </button>
      </div>

      {currentView === 'landing' && <PayviaLanding />}
      {currentView === 'tester' && <PayviaAPITester />}
      {currentView === 'compliance' && <ComplianceApp />}
      {currentView === 'analytics' && <MerchantAnalyticsApp />}
      {currentView === 'docs' && <DocsPortal />}
    </div>
  );
}

export default App;
