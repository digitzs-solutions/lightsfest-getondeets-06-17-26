import React, { useState } from 'react';
import { Download, Mail, FileText, Send, CheckCircle } from 'lucide-react';

interface Document {
  title: string;
  path: string;
  category: string;
  description: string;
}

export default function DocsPortal() {
  const [selectedDocs, setSelectedDocs] = useState<string[]>([]);
  const [emailSent, setEmailSent] = useState(false);

  const documents: Document[] = [
    {
      title: 'Quick Start Guide',
      path: '/pdf-docs/QUICK_START_DIGITZS.pdf',
      category: 'Getting Started',
      description: 'Essential guide to get started with Digitzs'
    },
    {
      title: 'PayVia Integration Guide',
      path: '/pdf-docs/PAYVIA_INTEGRATION.pdf',
      category: 'Integration',
      description: 'Complete PayVia wrapper implementation guide'
    },
    {
      title: 'TokenEx Setup',
      path: '/pdf-docs/TOKENEX_SETUP.pdf',
      category: 'Integration',
      description: 'TokenEx tokenization setup and configuration'
    },
    {
      title: 'Security Key Setup',
      path: '/pdf-docs/SETUP_DIGITZS_SECURITY_KEY.pdf',
      category: 'Security',
      description: 'Configure NMI security keys for Digitzs'
    },
    {
      title: 'TicketSocket Setup',
      path: '/pdf-docs/TICKETSOCKET_SETUP.pdf',
      category: 'Integration',
      description: 'Event registration and ticket management'
    },
    {
      title: 'Deployment Guide',
      path: '/pdf-docs/DEPLOYMENT.pdf',
      category: 'Operations',
      description: 'Production deployment procedures'
    },
    {
      title: 'End-to-End Flow',
      path: '/pdf-docs/DIGITZS_PAYVIA_END_TO_END.pdf',
      category: 'Architecture',
      description: 'Complete payment flow architecture'
    },
    {
      title: 'API QA Report',
      path: '/pdf-docs/PAYVIA_API_QA_REPORT.pdf',
      category: 'Quality',
      description: 'PayVia API testing and validation results'
    },
    {
      title: 'IXOPay Reference',
      path: '/pdf-docs/IXOPAY_TOKENEX_REFERENCE.pdf',
      category: 'Reference',
      description: 'IXOPay integration reference documentation'
    },
    {
      title: 'PCI DSS v4.0 AOC',
      path: '/pdf-docs/Digitzs_Solutions,_Inc._Level_One_PCI_DSS_v4-0-1_AOC_For_Payment_Service_Providers_(PSPs)_SIgned_by_LW_07.31.25.pdf',
      category: 'Compliance',
      description: 'Attestation of Compliance for Payment Service Providers'
    },
    {
      title: 'PCI DSS v4.0 ROC',
      path: '/pdf-docs/Digitzs_Solutions,_Inc._PCI_DSS_4.0_Level_One_ROC_(Report_on_Compliance)_for_PSPs_(Payment_Service_Providers)_-_(DigitzsCyber@12k4)_Final_08.11.25_Resaved_12.17.25.pdf',
      category: 'Compliance',
      description: 'Report on Compliance for Payment Service Providers'
    },
    {
      title: 'Direct Integration',
      path: '/pdf-docs/tokenex-architecture/DIGITZS_DIRECT_INTEGRATION.pdf',
      category: 'Architecture',
      description: 'Direct TokenEx to NMI integration architecture'
    },
    {
      title: 'NMI Security Key',
      path: '/pdf-docs/tokenex-architecture/DIGITZS_NMI_SECURITY_KEY.pdf',
      category: 'Architecture',
      description: 'Security key implementation details'
    },
    {
      title: 'Implementation Status',
      path: '/pdf-docs/tokenex-architecture/IMPLEMENTATION_STATUS.pdf',
      category: 'Architecture',
      description: 'Current implementation and testing status'
    },
    {
      title: 'PayVia Wrapper Details',
      path: '/pdf-docs/tokenex-architecture/PAYVIA_WRAPPER_DETAILS.pdf',
      category: 'Architecture',
      description: 'PayVia wrapper architecture and flow'
    },
    {
      title: 'TokenEx Process',
      path: '/pdf-docs/tokenex-architecture/TOKENEX_END_TO_END_PROCESS.pdf',
      category: 'Architecture',
      description: 'End-to-end tokenization process flow'
    }
  ];

  const categories = Array.from(new Set(documents.map(doc => doc.category)));

  const toggleDoc = (path: string) => {
    console.log('Toggling doc:', path);
    setSelectedDocs(prev => {
      const newSelection = prev.includes(path)
        ? prev.filter(p => p !== path)
        : [...prev, path];
      console.log('New selection:', newSelection);
      return newSelection;
    });
  };

  const selectAll = () => {
    setSelectedDocs(documents.map(d => d.path));
  };

  const clearSelection = () => {
    setSelectedDocs([]);
  };

  const downloadArchive = () => {
    window.open('/all-docs.tar.gz', '_blank');
  };

  const sendEmailOutlook = () => {
    console.log('Outlook button clicked! Selected docs:', selectedDocs);

    if (selectedDocs.length === 0) {
      alert('Please select at least one document first');
      return;
    }

    const selectedDocsList = documents
      .filter(doc => selectedDocs.includes(doc.path))
      .map(doc => `• ${doc.title} - ${doc.description}`)
      .join('\n');

    const subject = encodeURIComponent('Digitzs Documentation Package');
    const body = encodeURIComponent(`Hello,

I'm sharing the following Digitzs documentation with you:

${selectedDocsList}

You can access these documents at:
${window.location.origin}/docs

Best regards`);

    const mailtoUrl = `mailto:?subject=${subject}&body=${body}`;
    console.log('Opening mailto URL:', mailtoUrl);

    window.location.href = mailtoUrl;
    setEmailSent(true);
    setTimeout(() => setEmailSent(false), 3000);
  };

  const sendEmailGmail = () => {
    console.log('Gmail button clicked! Selected docs:', selectedDocs);

    if (selectedDocs.length === 0) {
      alert('Please select at least one document first');
      return;
    }

    const selectedDocsList = documents
      .filter(doc => selectedDocs.includes(doc.path))
      .map(doc => `• ${doc.title} - ${doc.description}`)
      .join('%0D%0A');

    const subject = encodeURIComponent('Digitzs Documentation Package');
    const body = `Hello,%0D%0A%0D%0AI'm sharing the following Digitzs documentation with you:%0D%0A%0D%0A${selectedDocsList}%0D%0A%0D%0AYou can access these documents at:%0D%0A${window.location.origin}/docs%0D%0A%0D%0ABest regards`;

    const gmailUrl = `https://mail.google.com/mail/?view=cm&fs=1&su=${subject}&body=${body}`;
    console.log('Opening Gmail URL:', gmailUrl);

    const link = document.createElement('a');
    link.href = gmailUrl;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setEmailSent(true);
    setTimeout(() => setEmailSent(false), 3000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-slate-900 mb-4">
            Digitzs Documentation Portal
          </h1>
          <p className="text-lg text-slate-600">
            Access, download, and share technical documentation
          </p>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 mb-8">
          <div className="flex flex-wrap gap-4 items-center justify-between">
            <div className="flex gap-3">
              <button
                onClick={selectAll}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-medium transition-colors"
              >
                Select All
              </button>
              <button
                onClick={clearSelection}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-medium transition-colors"
              >
                Clear Selection
              </button>
            </div>
            <div className="flex gap-3 flex-wrap">
              <button
                onClick={downloadArchive}
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors"
              >
                <Download className="w-4 h-4" />
                Download All (.tar.gz)
              </button>
              <button
                onClick={sendEmailGmail}
                disabled={selectedDocs.length === 0}
                className="flex items-center gap-2 px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {emailSent ? (
                  <>
                    <CheckCircle className="w-4 h-4" />
                    Ready
                  </>
                ) : (
                  <>
                    <Mail className="w-4 h-4" />
                    Gmail ({selectedDocs.length})
                  </>
                )}
              </button>
              <button
                onClick={sendEmailOutlook}
                disabled={selectedDocs.length === 0}
                className="flex items-center gap-2 px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {emailSent ? (
                  <>
                    <CheckCircle className="w-4 h-4" />
                    Ready
                  </>
                ) : (
                  <>
                    <Mail className="w-4 h-4" />
                    Outlook/365 ({selectedDocs.length})
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {categories.map(category => {
          const categoryDocs = documents.filter(doc => doc.category === category);
          return (
            <div key={category} className="mb-8">
              <h2 className="text-2xl font-bold text-slate-900 mb-4 flex items-center gap-2">
                <FileText className="w-6 h-6 text-blue-600" />
                {category}
              </h2>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                {categoryDocs.map(doc => (
                  <div
                    key={doc.path}
                    className={`bg-white rounded-lg border-2 transition-all cursor-pointer hover:shadow-md ${
                      selectedDocs.includes(doc.path)
                        ? 'border-blue-600 shadow-md'
                        : 'border-slate-200'
                    }`}
                    onClick={() => toggleDoc(doc.path)}
                  >
                    <div className="p-5">
                      <div className="flex items-start justify-between mb-3">
                        <h3 className="font-semibold text-slate-900 text-lg">
                          {doc.title}
                        </h3>
                        <input
                          type="checkbox"
                          checked={selectedDocs.includes(doc.path)}
                          onChange={() => toggleDoc(doc.path)}
                          className="w-5 h-5 text-blue-600 rounded focus:ring-2 focus:ring-blue-500"
                          onClick={(e) => e.stopPropagation()}
                        />
                      </div>
                      <p className="text-sm text-slate-600 mb-4">
                        {doc.description}
                      </p>
                      <a
                        href={doc.path}
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={(e) => e.stopPropagation()}
                        className="inline-flex items-center gap-2 text-blue-600 hover:text-blue-700 font-medium text-sm"
                      >
                        <Download className="w-4 h-4" />
                        Download PDF
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}

        <div className="bg-blue-50 rounded-xl border border-blue-200 p-6 mt-12">
          <div className="flex gap-4">
            <Send className="w-6 h-6 text-blue-600 flex-shrink-0 mt-1" />
            <div>
              <h3 className="font-semibold text-blue-900 mb-2">
                Email Integration with Gmail & Microsoft 365
              </h3>
              <p className="text-blue-800 mb-3">
                Choose your preferred email service to compose a pre-filled message with your selected documents:
              </p>
              <ul className="text-sm text-blue-700 space-y-2">
                <li>
                  <strong>Gmail:</strong> Opens Gmail web interface in a new tab with the email ready to send
                </li>
                <li>
                  <strong>Outlook/365:</strong> Opens your default email client (Outlook, Microsoft 365, Apple Mail, etc.) with the email draft
                </li>
              </ul>
              <p className="text-sm text-blue-700 mt-3">
                Both options include document descriptions and a link to this portal for easy access.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
